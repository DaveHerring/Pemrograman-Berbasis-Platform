<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width-device-width,initil-scale=1">
        <title>UPDATE ASISTEN PRAKTIKUM</title>
    </head>
    <body>
        <div class = "modal-body">
            <form method ="post" action = "proseslogin.php">
                <div class="form-group" align="left">
                <label for="NIM"><span class="glyphicon glyphicon-user"></span>NIM:</label>
                <input type ="text" class="form-control" id="NIM" placeholder="Ketikan NIM anda" name="NIM" autocomplete="off" required>
</div>
<div class = "modal-body">
            <form method ="post" action = "proseslogin.php">
                <div class="form-group" align="left">
                <label for="NAMA"><span class="glyphicon glyphicon-user"></span>NAMA:</label>
                <input type ="text" class="form-control" id="NAMA" placeholder="Ketikan NAMA anda" name="NAMA" autocomplete="off" required>
</div>
<div class = "modal-body">
            <form method ="post" action = "proseslogin.php">
                <div class="form-group" align="left">
                <label for="PRAKTIKUM"><span class="glyphicon glyphicon-user"></span>PRAKTIKUM:</label>
                <input type ="text" class="form-control" id="PRAKTIKUM" placeholder="Ketikan PRAKTIKUM anda" name="PRAKTIKUM" autocomplete="off" required>
</div>
<div class = "modal-body">
            <form method ="post" action = "proseslogin.php">
                <div class="form-group" align="left">
                <label for="IPK"><span class="glyphicon glyphicon-user"></span>IPK:</label>
                <input type ="text" class="form-control" id="IPK" placeholder="Ketikan IPK anda" name="IPK" autocomplete="off" required>
</div>
</body>
<div class="modal-footer">
    <button type ="submit" name="Update" class="btn btn-default btn-success">Update</button>           
</html>