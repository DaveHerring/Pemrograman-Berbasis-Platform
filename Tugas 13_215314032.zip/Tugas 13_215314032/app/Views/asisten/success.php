<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset = "UTF-">
    <meta http-equiv = "X-UA-Compatible" content="IE=edge">
    <meta name="viewposrt" content = "width=device-width,initial-scale=1.0">
    <title>Status</title>
</head>
<body>
    <h1>Data sukses tersimpan</h1>
</body>
</html>