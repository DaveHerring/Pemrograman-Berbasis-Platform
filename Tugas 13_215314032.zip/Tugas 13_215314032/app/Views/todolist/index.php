<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewpost content = " width="width=device-width,initial-scale=1.0">
</head>

<body>
    <form action="todolist/save" method="post">
        <h2> Aplikasi TO DO LIST</h2>
        <br><br><br>
        <label> Masukkan Kegiatan</label>
        <input type="text" name="kegiatan" id="kegiatan">
        <input name="add" type="submit" value="Tambahkan">
    </form>

    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "todolist";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_POST['add'])) {
        $kegiatan = $_POST['kegiatan'];
        $sql = "INSERT INTO tododb (kegiatan) VALUES ('$kegiatan')";
        $query = mysqli_query($conn, $sql);
    }

    if (isset($_GET['selesai'])) {
        $selesai = $_GET['selesai'];
        $sql = "UPDATE tododb SET status = 'selesai' WHERE  idkegiatan = $selesai";
        $query = mysqli_query($conn, $sql);
    }
    if (isset($_GET['hapus'])) {
        $kegiatan = $_GET['hapus'];
        $sql = "DELETE FROM tododb WHERE idkegiatan = $kegiatan";
        $query = mysqli_query($conn, $sql);
    }
    $sql = "SELECT * FROM tododb";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead><tr><th>No</th><th>Kegiatan</th><th>Status</th><th>Aksi</th></tr></thead>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["idkegiatan"] . "</td><td>" . $row["kegiatan"] . "</td><td>" . $row["status"] . "</td><td>";
            echo "<a href='" . $_SERVER['PHP_SELF'] . "?selesai=" . $row["idkegiatan"] . "'>Selesai</a> ";
            echo "<a href='" . $_SERVER['PHP_SELF'] . "?hapus=" . $row["idkegiatan"] . "'>Hapus</a> ";
            echo "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "Tidak ada kegiatan yang tersimpan.";
        $sql = "ALTER TABLE tododb AUTO_INCREMENT = 1";
        $query = mysqli_query($conn, $sql);
    }
    $conn->close();
    ?>
</body>

</html>