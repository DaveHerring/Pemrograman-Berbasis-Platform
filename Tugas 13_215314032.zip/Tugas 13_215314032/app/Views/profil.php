<!DOCTYPE html>

<head>
    <title>KTP</title>
</head>

<body>
    <table border="1">
        <tr>
            <td colspan="3">
                <center>KTP</center>
            </td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>Valensia Stiven</td>
            <td rowspan="3"><img width='100' src=
            "https://1.bp.blogspot.com/-vW6DioB-bvw/U05y7UYPZ4I/AAAAAAAABec/hCMJ6QbDpvo/s1600/song+hye+kyo.jpg"></td>
        </tr>
        <tr>
            <td>NIK</td>
            <td>210</td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>Yogyakarta</td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>14 Oktober 2022</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>Sleman</td>
        </tr>
    </table>
</body>