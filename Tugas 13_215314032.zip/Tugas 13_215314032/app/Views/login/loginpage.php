<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv ="X-UA-Compatible" contents="IE=edge">
        <meta name ="viewport" content="width=device-width,initial-scale=1.0">
        <title>Login Form</title>
    </head>
    <body>
            <form method ="post" action = "login/check">
                <?= csrf_field()?>
                user:<input type="text" name="usr"/><br>
                Password:<input type="text" name="pwd"/><br>
                <input type="submit" name="submit" value="login" />
</form>
            </body>
</html>